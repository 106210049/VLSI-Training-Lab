`define PROG_BUS_IDLE        3'b000
`define PROG_READ_CYCLE		 3'b001
`define PROG_WRITE_CYCLE	 3'b100
`define PROG_DATA_OUT		 3'b010
`define PROG_BUS_CLEAR       3'b011
`define PROG_WRITE_ASSERT    3'b101
`define PROG_WRITE_DEASSERT  3'b110
`define PROG_WRITE_CLEAR     3'b111

