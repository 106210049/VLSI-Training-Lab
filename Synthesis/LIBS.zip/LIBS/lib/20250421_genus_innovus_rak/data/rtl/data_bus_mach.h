`define DATA_BUS_IDLE        3'b000
`define DATA_READ_CYCLE		     3'b001
`define DATA_WRITE_CYCLE		     3'b100
`define DATA_OUT		     3'b010
`define DATA_BUS_CLEAR       3'b011
`define DATA_WRITE_ASSERT    	 3'b101
`define DATA_WRITE_DEASSERT       3'b110
`define DATA_WRITE_CLEAR          3'b111

